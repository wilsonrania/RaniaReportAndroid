Rania Report Android App - Starter Project

यह Android Studio प्रोजेक्ट है। वेबसाइट का URL पहले से सेट है:
https://raniareport.blogspot.com/

प्रोजेक्ट खोलने और APK बनाने के चरण:
1. कंप्यूटर में Android Studio इंस्टॉल करें।
2. Android Studio > Open चुनें और इस ZIP से निकला RaniaReportAndroid फोल्डर खोलें।
3. Gradle Sync पूरा होने दें। Android SDK Platform 35 इंस्टॉल करने का विकल्प आए तो इंस्टॉल करें।
4. Build > Build Bundle(s) / APK(s) > Build APK(s) चुनें।
5. APK आम तौर पर app/build/outputs/apk/debug/app-debug.apk में बनेगा।
6. APK को मोबाइल में भेजकर इंस्टॉल करें। पहली बार Android में "Install unknown apps" की अनुमति देनी पड़ सकती है।

शामिल:
- वेबसाइट WebView में खुलती है
- JavaScript और DOM storage सक्षम
- वेबसाइट के HTML file-upload chooser के लिए समर्थन
- DownloadManager से डाउनलोड (डाउनलोड फ़ोल्डर)
- Android Print Framework से मौजूदा पेज प्रिंट
- Back, Home, Reload, Browser में खोलें

महत्वपूर्ण परीक्षण:
- इस रनटाइम में Android SDK/Gradle उपलब्ध नहीं है, इसलिए यहाँ APK compile नहीं किया गया है।
- Android WebView सभी PDF को स्वयं render नहीं करता। PDF लिंक यदि डाउनलोड के रूप में आता है तो DownloadManager उसे सेव करेगा; PDF देखने के लिए मोबाइल में PDF viewer की जरूरत हो सकती है।
- वेबसाइट के कुछ third-party pop-up/new-window व्यवहार या किसी खास Blogger widget की अलग जाँच वास्तविक Android फोन पर करनी होगी।
- वेबसाइट की तरफ से उपलब्ध न होने वाली सुविधा ऐप अपने आप नहीं बना सकता।
